Routine operations host snapshot. Determine which system and service identity are relevant.
