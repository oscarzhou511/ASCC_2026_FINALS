hostname
systemctl status telemetry
grep -i token /var/log/auth.log
exit
